define(
    [
        'mage/storage',
        'Magento_Checkout/js/model/quote',
        'Magento_Checkout/js/model/resource-url-manager'
    ],
    function (storage, quote, resourceUrlManager) {
        'use strict';

        return function (date) {

            var payload = {
                deliveryDate: date
            };

            return storage.post(
                resourceUrlManager.getUrlForSetDeliveryDate(quote),
                JSON.stringify(payload)
            );
        };
    }
);
