define([
    'jquery',
    'underscore',
    'ko',
    'Visy_Checkout/js/action/set-delivery-date',
    'Magento_Checkout/js/model/checkout-data-resolver',
    'mage/calendar',
    'mage/validation'
], function ($,
             _,
             ko,
             setDeliveryDate,
             checkoutDataResolver,
             ) {
    'use strict';

    return function (Shipping) {

        var priorityWarehouseForDate = {};
        var deliveryTypeSubscription;

        return Shipping.extend({

            selectedToday: ko.observable(false),
            datePicker: null,
            shippingDetails: {
                deliveryDate: ko.observable(),
                displayDate: ko.observable('displayDate')
            },

            initialize: function () {
                var self = this;
                this._super();
                self.initDatePicker();
            },

            initDatePicker: function () {
                var self = this;

                ko.bindingHandlers.datepicker = {
                    init: function (element, valueAccessor) {
                        var $el = $(element);

                        var options = {
                            minDate: 0,
                            dateFormat: 'dd / mm / yy',
                            onSelect: function (date) {
                                /* Get the today's date but we don't wat the time */
                                var today = new Date();
                                today.setHours(0);
                                today.setMinutes(0);
                                today.setSeconds(0);

                                /* The selected date from the date picker - parsed as a Date object */
                                var selectedDate = $.datepicker.parseDate('dd / mm / yy', date);

                                if (Date.parse(today) === Date.parse(selectedDate)) {
                                    self.selectedToday(true);
                                    //sameDayDeliveryService.isToday = true;
                                } else {
                                    self.selectedToday(false);
                                    //sameDayDeliveryService.isToday = false;
                                }

                                /* Different date format for display */
                                var displayDate = $.datepicker.formatDate('D, d M yy', selectedDate);
                                if (self.selectedToday()) {
                                    displayDate += ' (Today)';
                                }
                                self.shippingDetails.displayDate(displayDate);

                                /* Set the warehouse for the selected date */
                                //var warehouseForDate = priorityWarehouseForDate[selectedDate];
                                //self.shippingDetails.warehouseId(warehouseForDate);

                                /*sameDayDeliveryService.selectedDate = selectedDate;
                                sameDayDeliveryService.warehouseID = warehouseForDate;
                                sameDayDeliveryService.priorityWarehouseForDate = priorityWarehouseForDate;*/

                                /* Send a post back to the server with the delivery date */
                                setDeliveryDate($.datepicker.formatDate('yy-mm-dd', selectedDate))
                                    .done(function () {
                                        checkoutDataResolver.resolveEstimationAddress();
                                    });

                                /* Trigger validation */
                                $el.closest('form').trigger('validate');
                            }
                        };
                        if (valueAccessor()) {
                            self.datePicker = $el.datepicker(options);
                        }

                    }
                };
            },

        });
    };
});