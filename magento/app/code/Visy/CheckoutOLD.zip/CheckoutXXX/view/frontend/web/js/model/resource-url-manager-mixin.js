define([
], function () {
    'use strict';

    return function (resourceUrlManager) {

        resourceUrlManager.getUrlForSetDeliveryDate = function(quote) {
            var params = {cartId: quote.getQuoteId()};
            var urls = {
                'guest': '/checkout-delivery/:cartId/delivery-date',
                'customer': '/checkout-delivery/mine/delivery-date'
            };
            return this.getUrl(urls, params);
        };

        return resourceUrlManager;

    };
});