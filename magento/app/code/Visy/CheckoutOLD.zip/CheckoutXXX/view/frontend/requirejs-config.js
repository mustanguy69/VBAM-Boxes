var config = {
    config: {
        mixins: {
            /*'Magento_Checkout/js/action/place-order': {
                'Visy_Checkout/js/action/place-order-mixin': true
            },*/
            /*'Magento_Checkout/js/action/set-payment-information': {
                'Visy_Checkout/js/action/set-payment-information-mixin': true
            },*/
            'Magento_Checkout/js/action/set-shipping-information': {
                'Visy_Checkout/js/action/set-shipping-information-mixin': true
            },
            'Magento_Checkout/js/view/shipping': {
                'Visy_Checkout/js/view/shipping-mixin': true
            },
            'Magento_Checkout/js/model/resource-url-manager': {
                'Visy_Checkout/js/model/resource-url-manager-mixin': true
            },
        }
    }
    };