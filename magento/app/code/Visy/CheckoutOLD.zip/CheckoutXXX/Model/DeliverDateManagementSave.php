<?php
/**
 * VISY IDT Ltd.
 *
 * @category    Visy
 * @package     Checkout
 * @author      VISY IDT Team <contact@visy.com>
 * @copyright   Copyright (c) 2020 Visy IDT Ltd. (http://visy.com.au)
 */
namespace Visy\Checkout\Model;

use Magento\Quote\Api\CartRepositoryInterface;
use Visy\Checkout\Api\DeliverDateManagementInterface;

/**
 * Class DeliverDateManagementSave
 * @package Visy\Checkout\Model
 */
class DeliverDateManagementSave implements DeliverDateManagementInterface
{
    /**
     * @var CartRepositoryInterface
     */
    private $cartRepository;

    /**
     * DeliveryDateSave constructor.
     * @param CartRepositoryInterface $cartRepository
     */
    public function __construct(
        CartRepositoryInterface $cartRepository
    ) {
        $this->cartRepository = $cartRepository;
    }

    /**
     * @param string $cartId
     * @param string $giftCardMessage
     * @return bool|string
     */
    public function saveDeliverDate(
        $cartId,
        $deliveryDate
    ) {
        try {
            $quote = $this->cartRepository->getActive($cartId);
            $quote->setDeliveryDate($deliveryDate);
            $this->cartRepository->save($quote);
            return true;
        } catch (\Exception $e) {
            return json_encode(['error' => $e->getMessage()]);
        }
    }
}
