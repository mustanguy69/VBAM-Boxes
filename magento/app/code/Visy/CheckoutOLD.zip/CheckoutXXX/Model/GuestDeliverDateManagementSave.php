<?php
/**
 * VISY IDT Ltd.
 *
 * @category    Visy
 * @package     Checkout
 * @author      VISY IDT Team <contact@visy.com>
 * @copyright   Copyright (c) 2020 Visy IDT Ltd. (http://visy.com.au)
 */
namespace Visy\Checkout\Model;

use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\QuoteIdMaskFactory;
use Visy\Checkout\Api\GuestDeliverDateManagementInterface;

/**
 * Class GuestDeliverDateManagementSave
 * @package Visy\Checkout\Model
 */
class GuestDeliverDateManagementSave implements GuestDeliverDateManagementInterface
{
    /**
     * @var CartRepositoryInterface
     */
    private $cartRepository;

    /**
     * @var QuoteIdMaskFactory
     */
    private $maskFactory;

    /**
     * GuestDeliverDateManagementSave constructor.
     * @param CartRepositoryInterface $cartRepository
     * @param QuoteIdMaskFactory $maskFactory
     */
    public function __construct(
        CartRepositoryInterface $cartRepository,
        QuoteIdMaskFactory $maskFactory
    ) {
        $this->cartRepository = $cartRepository;
        $this->maskFactory = $maskFactory;
    }

    /**
     * @param string $cartId
     * @param string $giftCardMessage
     * @return bool|string
     */
    public function saveDeliverDate(
        $cartId,
        $deliveryDate
    ) {
        try {
            $quoteMask = $this->maskFactory->create()->load($cartId, 'masked_id');
            $quote = $this->cartRepository->get($quoteMask->getQuoteId());
            $quote->setDeliveryDate($deliveryDate);
            $this->cartRepository->save($quote);
            return true;
        } catch (\Exception $e) {
            return json_encode(['error' => $e->getMessage()]);
        }
    }
}
