<?php
/**
 * VISY IDT Ltd.
 *
 * @category    Visy
 * @package     Checkout
 * @author      VISY IDT Team <contact@visy.com>
 * @copyright   Copyright (c) 2020 Visy IDT Ltd. (http://visy.com.au)
 */
namespace Visy\Checkout\Api;

/**
 * Interface DeliverDateManagementInterface
 * @package Visy\CardMessages\Api
 */
interface DeliverDateManagementInterface
{
    /**
     * @param string $cartId
     * @param string $deliverDate
     * @return mixed
     */
    public function saveDeliverDate(
        $cartId,
        $deliveryDate
    );
}
