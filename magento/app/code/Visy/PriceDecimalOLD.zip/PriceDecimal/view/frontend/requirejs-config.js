var config = {
    map: {
        '*': {
            'Magento_Catalog/js/price-utils' : 'Visy_PriceDecimal/js/price-utils'
        }
    }
};